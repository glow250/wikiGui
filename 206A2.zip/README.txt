This assignment was created using the ECSE Linux Lab Machine.
To run this file navigate to the top folder that contains src and bin and type 
./myscript.sh using terminal.
This assumes java is in the file:
/usr/lib/jvm/jdk1.8.0_144/bin/java
Where it is located in on the lab computers
