/usr/lib/jvm/jdk1.8.0_144/bin/java -cp bin main.Main
